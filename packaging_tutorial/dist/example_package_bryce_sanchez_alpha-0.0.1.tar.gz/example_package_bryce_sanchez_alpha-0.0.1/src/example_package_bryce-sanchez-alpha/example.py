def add_one(number:int|float) -> int|float:
    return number + 1
